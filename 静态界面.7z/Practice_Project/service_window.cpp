#include "service_window.h"
#include "ui_service_window.h"

Service_Window::Service_Window(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Service_Window)
{
    ui->setupUi(this);
}

Service_Window::~Service_Window()
{
    delete ui;
}

void Service_Window::on_pushButton_clicked()
{
    maintainservicew = new MaintainService;
    maintainservicew -> show();
}

void Service_Window::on_pushButton_2_clicked()
{
    printconfirmtablew = new PrintConfirmTable;
    printconfirmtablew -> show();
}
