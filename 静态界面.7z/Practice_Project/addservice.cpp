#include "addservice.h"
#include "ui_addservice.h"

AddService::AddService(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AddService)
{
    ui->setupUi(this);
}

AddService::~AddService()
{
    delete ui;
}
