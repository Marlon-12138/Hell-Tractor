#ifndef OUTPUTEQUIP_H
#define OUTPUTEQUIP_H

#include <QWidget>

namespace Ui {
class OutputEquip;
}

class OutputEquip : public QWidget
{
    Q_OBJECT

public:
    explicit OutputEquip(QWidget *parent = nullptr);
    ~OutputEquip();

private:
    Ui::OutputEquip *ui;
};

#endif // OUTPUTEQUIP_H
