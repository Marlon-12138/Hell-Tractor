#ifndef DELETESERVICE_H
#define DELETESERVICE_H

#include <QWidget>

namespace Ui {
class DeleteService;
}

class DeleteService : public QWidget
{
    Q_OBJECT

public:
    explicit DeleteService(QWidget *parent = nullptr);
    ~DeleteService();

private:
    Ui::DeleteService *ui;
};

#endif // DELETESERVICE_H
