#ifndef ADDMONEY_H
#define ADDMONEY_H

#include <QWidget>

namespace Ui {
class AddMoney;
}

class AddMoney : public QWidget
{
    Q_OBJECT

public:
    explicit AddMoney(QWidget *parent = nullptr);
    ~AddMoney();

private:
    Ui::AddMoney *ui;
};

#endif // ADDMONEY_H
