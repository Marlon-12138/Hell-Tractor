#ifndef MODIFYSERVICE_H
#define MODIFYSERVICE_H

#include <QWidget>

namespace Ui {
class ModifyService;
}

class ModifyService : public QWidget
{
    Q_OBJECT

public:
    explicit ModifyService(QWidget *parent = nullptr);
    ~ModifyService();

private:
    Ui::ModifyService *ui;
};

#endif // MODIFYSERVICE_H
