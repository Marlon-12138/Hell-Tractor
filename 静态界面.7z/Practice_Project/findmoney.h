#ifndef FINDMONEY_H
#define FINDMONEY_H

#include <QWidget>

namespace Ui {
class FindMoney;
}

class FindMoney : public QWidget
{
    Q_OBJECT

public:
    explicit FindMoney(QWidget *parent = nullptr);
    ~FindMoney();

private:
    Ui::FindMoney *ui;
};

#endif // FINDMONEY_H
