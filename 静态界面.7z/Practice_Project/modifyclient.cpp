#include "modifyclient.h"
#include "ui_modifyclient.h"

ModifyClient::ModifyClient(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ModifyClient)
{
    ui->setupUi(this);
}

ModifyClient::~ModifyClient()
{
    delete ui;
}
