#ifndef MODIFYCLIENT_H
#define MODIFYCLIENT_H

#include <QWidget>

namespace Ui {
class ModifyClient;
}

class ModifyClient : public QWidget
{
    Q_OBJECT

public:
    explicit ModifyClient(QWidget *parent = nullptr);
    ~ModifyClient();

private:
    Ui::ModifyClient *ui;
};

#endif // MODIFYCLIENT_H
