#include "printconfirmtable.h"
#include "ui_printconfirmtable.h"

PrintConfirmTable::PrintConfirmTable(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PrintConfirmTable)
{
    ui->setupUi(this);
}

PrintConfirmTable::~PrintConfirmTable()
{
    delete ui;
}
