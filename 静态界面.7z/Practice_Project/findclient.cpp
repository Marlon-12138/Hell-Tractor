#include "findclient.h"
#include "ui_findclient.h"

FindClient::FindClient(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FindClient)
{
    ui->setupUi(this);
}

FindClient::~FindClient()
{
    delete ui;
}
