#ifndef FINDEQUIP_H
#define FINDEQUIP_H

#include <QWidget>

namespace Ui {
class FindEquip;
}

class FindEquip : public QWidget
{
    Q_OBJECT

public:
    explicit FindEquip(QWidget *parent = nullptr);
    ~FindEquip();

private:
    Ui::FindEquip *ui;
};

#endif // FINDEQUIP_H
