#include "addparts.h"
#include "ui_addparts.h"

AddParts::AddParts(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AddParts)
{
    ui->setupUi(this);
}

AddParts::~AddParts()
{
    delete ui;
}
