#ifndef DELETECLIENT_H
#define DELETECLIENT_H

#include <QWidget>

namespace Ui {
class DeleteClient;
}

class DeleteClient : public QWidget
{
    Q_OBJECT

public:
    explicit DeleteClient(QWidget *parent = nullptr);
    ~DeleteClient();

private:
    Ui::DeleteClient *ui;
};

#endif // DELETECLIENT_H
