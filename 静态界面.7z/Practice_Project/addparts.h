#ifndef ADDPARTS_H
#define ADDPARTS_H

#include <QWidget>

namespace Ui {
class AddParts;
}

class AddParts : public QWidget
{
    Q_OBJECT

public:
    explicit AddParts(QWidget *parent = nullptr);
    ~AddParts();

private:
    Ui::AddParts *ui;
};

#endif // ADDPARTS_H
