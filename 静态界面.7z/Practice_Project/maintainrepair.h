#ifndef MAINTAINREPAIR_H
#define MAINTAINREPAIR_H

#include <QWidget>
#include "deleterepair.h"

namespace Ui {
class MaintainRepair;
}

class MaintainRepair : public QWidget
{
    Q_OBJECT

public:
    explicit MaintainRepair(QWidget *parent = nullptr);
    DeleteRepair *deleterepairw;
    ~MaintainRepair();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::MaintainRepair *ui;
};

#endif // MAINTAINREPAIR_H
