#include "deleterepair.h"
#include "ui_deleterepair.h"

DeleteRepair::DeleteRepair(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DeleteRepair)
{
    ui->setupUi(this);
}

DeleteRepair::~DeleteRepair()
{
    delete ui;
}
