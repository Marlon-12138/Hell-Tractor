#ifndef MAINTAINSERVICE_H
#define MAINTAINSERVICE_H

#include <QMainWindow>
#include "addservice.h"
#include "findservice.h"
#include "modifyservice.h"
#include "deleteservice.h"

namespace Ui {
class MaintainService;
}

class MaintainService : public QMainWindow
{
    Q_OBJECT

public:
    explicit MaintainService(QWidget *parent = nullptr);
    AddService *addservicew;
    FindService *findservicew;
    ModifyService *modifyservicew;
    DeleteService *deleteservicew;
    ~MaintainService();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::MaintainService *ui;
};

#endif // MAINTAINSERVICE_H
