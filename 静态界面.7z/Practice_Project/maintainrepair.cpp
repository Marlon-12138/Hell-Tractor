#include "maintainrepair.h"
#include "ui_maintainrepair.h"
#include <QString>
#include <QInputDialog>
#include <QMdiSubWindow>

MaintainRepair::MaintainRepair(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MaintainRepair)
{
    ui->setupUi(this);
}

MaintainRepair::~MaintainRepair()
{
    delete ui;
}

void MaintainRepair::on_pushButton_2_clicked()
{
    deleterepairw = new DeleteRepair;
    QMdiSubWindow *child = ui->mdiArea->addSubWindow(deleterepairw);
    child->setWindowFlags(Qt::FramelessWindowHint);
    child->setFixedSize(600,500);
    child->show();

}

void MaintainRepair::on_pushButton_3_clicked()
{
    QString string = QInputDialog::getText(this,tr("删除维修任务"), tr("请输入客户姓名："));
}
