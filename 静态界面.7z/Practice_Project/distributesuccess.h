#ifndef DISTRIBUTESUCCESS_H
#define DISTRIBUTESUCCESS_H

#include <QDialog>

namespace Ui {
class DistributeSuccess;
}

class DistributeSuccess : public QDialog
{
    Q_OBJECT

public:
    explicit DistributeSuccess(QWidget *parent = nullptr);
    ~DistributeSuccess();

private:
    Ui::DistributeSuccess *ui;
};

#endif // DISTRIBUTESUCCESS_H
