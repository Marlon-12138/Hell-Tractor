#include "outputequip.h"
#include "ui_outputequip.h"

OutputEquip::OutputEquip(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::OutputEquip)
{
    ui->setupUi(this);
}

OutputEquip::~OutputEquip()
{
    delete ui;
}
