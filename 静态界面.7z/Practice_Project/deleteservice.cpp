#include "deleteservice.h"
#include "ui_deleteservice.h"

DeleteService::DeleteService(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DeleteService)
{
    ui->setupUi(this);
}

DeleteService::~DeleteService()
{
    delete ui;
}
