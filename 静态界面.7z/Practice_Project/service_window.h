#ifndef SERVICE_WINDOW_H
#define SERVICE_WINDOW_H

#include <QMainWindow>
#include "maintainservice.h"
#include "printconfirmtable.h"

namespace Ui {
class Service_Window;
}

class Service_Window : public QMainWindow
{
    Q_OBJECT

public:
    explicit Service_Window(QWidget *parent = nullptr);
    MaintainService *maintainservicew;
    PrintConfirmTable *printconfirmtablew;
    ~Service_Window();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Service_Window *ui;
};

#endif // SERVICE_WINDOW_H
