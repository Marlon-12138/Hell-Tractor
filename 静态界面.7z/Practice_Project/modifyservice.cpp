#include "modifyservice.h"
#include "ui_modifyservice.h"

ModifyService::ModifyService(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ModifyService)
{
    ui->setupUi(this);
}

ModifyService::~ModifyService()
{
    delete ui;
}
