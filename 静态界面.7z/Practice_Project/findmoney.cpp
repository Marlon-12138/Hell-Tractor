#include "findmoney.h"
#include "ui_findmoney.h"

FindMoney::FindMoney(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FindMoney)
{
    ui->setupUi(this);
}

FindMoney::~FindMoney()
{
    delete ui;
}
