#include "distributerepair.h"
#include "ui_distributerepair.h"

DistributeRepair::DistributeRepair(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DistributeRepair)
{
    ui->setupUi(this);
}

DistributeRepair::~DistributeRepair()
{
    delete ui;
}
