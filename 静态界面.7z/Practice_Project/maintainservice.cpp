#include "maintainservice.h"
#include "ui_maintainservice.h"

#include <QMdiSubWindow>

MaintainService::MaintainService(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MaintainService)
{
    ui->setupUi(this);
}

MaintainService::~MaintainService()
{
    delete ui;
}

void MaintainService::on_pushButton_clicked()
{
    addservicew = new AddService;
    QMdiSubWindow *child = ui->mdiArea->addSubWindow(addservicew);
    child->setWindowFlags(Qt::FramelessWindowHint);
    child->setFixedSize(600,500);
    child->show();
}

void MaintainService::on_pushButton_2_clicked()
{
    findservicew = new FindService;
    QMdiSubWindow *child = ui->mdiArea->addSubWindow(findservicew);
    child->setWindowFlags(Qt::FramelessWindowHint);
    child->setFixedSize(600,500);
    child->show();
}

void MaintainService::on_pushButton_3_clicked()
{
    modifyservicew = new ModifyService;
    QMdiSubWindow *child = ui->mdiArea->addSubWindow(modifyservicew);
    child->setWindowFlags(Qt::FramelessWindowHint);
    child->setFixedSize(600,500);
    child->show();
}

void MaintainService::on_pushButton_4_clicked()
{
    deleteservicew = new DeleteService;
    QMdiSubWindow *child = ui->mdiArea->addSubWindow(deleteservicew);
    child->setWindowFlags(Qt::FramelessWindowHint);
    child->setFixedSize(600,500);
    child->show();
}
