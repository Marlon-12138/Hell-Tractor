#ifndef WAREHOUSE_WINDOW_H
#define WAREHOUSE_WINDOW_H

#include <QMainWindow>
#include "outputequip.h"
#include "findequip.h"
#include "addparts.h"

namespace Ui {
class Warehouse_Window;
}

class Warehouse_Window : public QMainWindow
{
    Q_OBJECT

public:
    explicit Warehouse_Window(QWidget *parent = nullptr);
    OutputEquip *outputequipw;
    FindEquip *findequipw;
    AddParts *addpartw;
    ~Warehouse_Window();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_5_clicked();

private:
    Ui::Warehouse_Window *ui;
};

#endif // WAREHOUSE_WINDOW_H
