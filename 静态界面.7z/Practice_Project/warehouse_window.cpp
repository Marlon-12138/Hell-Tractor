#include "warehouse_window.h"
#include "ui_warehouse_window.h"

#include <QInputDialog>
#include <QMdiSubWindow>
#include <QMessageBox>
#include <QString>

Warehouse_Window::Warehouse_Window(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Warehouse_Window)
{
    ui->setupUi(this);
}

Warehouse_Window::~Warehouse_Window()
{
    delete ui;
}

void Warehouse_Window::on_pushButton_clicked()
{
    outputequipw = new OutputEquip;
    QMdiSubWindow *child = ui->mdiArea->addSubWindow(outputequipw);
    child->setWindowFlags(Qt::FramelessWindowHint);
    child->setFixedSize(600,500);
    child->show();
}

void Warehouse_Window::on_pushButton_2_clicked()
{
    addpartw = new AddParts;
    QMdiSubWindow *child = ui->mdiArea->addSubWindow(addpartw);
    child->setWindowFlags(Qt::FramelessWindowHint);
    child->setFixedSize(600,500);
    child->show();
}

void Warehouse_Window::on_pushButton_5_clicked()
{
    findequipw = new FindEquip;
    QMdiSubWindow *child = ui->mdiArea->addSubWindow(findequipw);
    child->setWindowFlags(Qt::FramelessWindowHint);
    child->setFixedSize(600,500);
    child->show();

}
