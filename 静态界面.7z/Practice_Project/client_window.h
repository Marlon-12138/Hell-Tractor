#ifndef CLIENT_WINDOW_H
#define CLIENT_WINDOW_H
#include <QMainWindow>
#include "addclient.h"
#include "findclient.h"
#include "modifyclient.h"
#include "deleteclient.h"

namespace Ui {
class Client_Window;
}

class Client_Window : public QMainWindow
{
    Q_OBJECT

public:
    explicit Client_Window(QWidget *parent = nullptr);
    FindClient *FindClientw;
    AddClient *AddClientw;
    ModifyClient *ModifyClientw;
    DeleteClient *DeleteClientw;
    ~Client_Window();

private slots:
    void on_pushButton_2_clicked();

    void on_Add_text_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::Client_Window *ui;
};

#endif // CLIENT_WINDOW_H
