#include "repair_window.h"
#include "ui_repair_window.h"
#include <QMdiSubWindow>
#include <QMessageBox>

Repair_Window::Repair_Window(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Repair_Window)
{
    ui->setupUi(this);
}

Repair_Window::~Repair_Window()
{
    delete ui;
}

void Repair_Window::on_pushButton_clicked()
{
    distributerepairw = new DistributeRepair;
    QMdiSubWindow *child = ui->mdiArea->addSubWindow(distributerepairw);
    child->setWindowFlags(Qt::FramelessWindowHint);
    child->setFixedSize(600,500);
    child->show();
}

void Repair_Window::on_pushButton_2_clicked()
{
    findrepairw = new FindRepair;
    QMdiSubWindow *child = ui->mdiArea->addSubWindow(findrepairw);
    child->setWindowFlags(Qt::FramelessWindowHint);
    child->setFixedSize(600,500);
    child->show();
}

void Repair_Window::on_pushButton_3_clicked()
{
    maintainrepairw = new MaintainRepair;
    maintainrepairw -> show();
}
