#include "distributesuccess.h"
#include "ui_distributesuccess.h"

DistributeSuccess::DistributeSuccess(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DistributeSuccess)
{
    ui->setupUi(this);
}

DistributeSuccess::~DistributeSuccess()
{
    delete ui;
}
