#include "findequip.h"
#include "ui_findequip.h"

FindEquip::FindEquip(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FindEquip)
{
    ui->setupUi(this);
}

FindEquip::~FindEquip()
{
    delete ui;
}
