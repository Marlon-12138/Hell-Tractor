#include "client_window.h"
#include "ui_client_window.h"
#include <QMdiSubWindow>

Client_Window::Client_Window(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Client_Window)
{
    ui->setupUi(this);
}

Client_Window::~Client_Window()
{
    delete ui;
}

void Client_Window::on_pushButton_2_clicked()
{
    FindClientw = new FindClient;
    QMdiSubWindow *child = ui->mdiArea->addSubWindow(FindClientw);
    child->setWindowFlags(Qt::FramelessWindowHint);
    child->setFixedSize(600,500);
    child->show();
}

void Client_Window::on_Add_text_clicked()
{
    AddClientw = new AddClient;
    QMdiSubWindow *child = ui->mdiArea->addSubWindow(AddClientw);
    child->setWindowFlags(Qt::FramelessWindowHint);
    child->setFixedSize(600,500);
    child->show();
}

void Client_Window::on_pushButton_3_clicked()
{
    ModifyClientw = new ModifyClient;
    QMdiSubWindow *child = ui->mdiArea->addSubWindow(ModifyClientw);
    child->setWindowFlags(Qt::FramelessWindowHint);
    child->setFixedSize(600,500);
    child->show();
}

void Client_Window::on_pushButton_4_clicked()
{
    DeleteClientw = new DeleteClient;
    QMdiSubWindow *child = ui->mdiArea->addSubWindow(DeleteClientw);
    child->setWindowFlags(Qt::FramelessWindowHint);
    child->setFixedSize(600,500);
    child->show();
}
