#include "findrepair.h"
#include "ui_findrepair.h"

FindRepair::FindRepair(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FindRepair)
{
    ui->setupUi(this);
}

FindRepair::~FindRepair()
{
    delete ui;
}
