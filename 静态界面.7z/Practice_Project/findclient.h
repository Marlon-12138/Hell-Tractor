#ifndef FINDCLIENT_H
#define FINDCLIENT_H

#include <QWidget>

namespace Ui {
class FindClient;
}

class FindClient : public QWidget
{
    Q_OBJECT

public:
    explicit FindClient(QWidget *parent = nullptr);
    ~FindClient();

private:
    Ui::FindClient *ui;
};

#endif // FINDCLIENT_H
