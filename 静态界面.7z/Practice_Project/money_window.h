#ifndef MONEY_WINDOW_H
#define MONEY_WINDOW_H

#include <QMainWindow>
#include "findmoney.h"
#include "addmoney.h"

namespace Ui {
class Money_Window;
}

class Money_Window : public QMainWindow
{
    Q_OBJECT

public:
    explicit Money_Window(QWidget *parent = nullptr);
    FindMoney *findmoneyw;
    AddMoney *addmoneyw;
    ~Money_Window();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Money_Window *ui;
};

#endif // MONEY_WINDOW_H
