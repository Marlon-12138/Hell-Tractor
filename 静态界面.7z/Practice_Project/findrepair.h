#ifndef FINDREPAIR_H
#define FINDREPAIR_H

#include <QWidget>

namespace Ui {
class FindRepair;
}

class FindRepair : public QWidget
{
    Q_OBJECT

public:
    explicit FindRepair(QWidget *parent = nullptr);
    ~FindRepair();

private:
    Ui::FindRepair *ui;
};

#endif // FINDREPAIR_H
