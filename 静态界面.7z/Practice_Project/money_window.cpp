#include "money_window.h"
#include "ui_money_window.h"
#include <QMessageBox>
#include <QMdiSubWindow>

Money_Window::Money_Window(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Money_Window)
{
    ui->setupUi(this);
}

Money_Window::~Money_Window()
{
    delete ui;
}

void Money_Window::on_pushButton_clicked()
{
    addmoneyw = new AddMoney;
    QMdiSubWindow *child = ui->mdiArea->addSubWindow(addmoneyw);
    child->setWindowFlags(Qt::FramelessWindowHint);
    child->setFixedSize(600,500);
    child->show();
}

void Money_Window::on_pushButton_2_clicked()
{
    findmoneyw = new FindMoney;
    QMdiSubWindow *child = ui->mdiArea->addSubWindow(findmoneyw);
    child->setWindowFlags(Qt::FramelessWindowHint);
    child->setFixedSize(600,500);
    child->show();
}
