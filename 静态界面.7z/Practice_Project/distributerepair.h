#ifndef DISTRIBUTEREPAIR_H
#define DISTRIBUTEREPAIR_H

#include <QWidget>

namespace Ui {
class DistributeRepair;
}

class DistributeRepair : public QWidget
{
    Q_OBJECT

public:
    explicit DistributeRepair(QWidget *parent = nullptr);
    ~DistributeRepair();

private:
    Ui::DistributeRepair *ui;
};

#endif // DISTRIBUTEREPAIR_H
