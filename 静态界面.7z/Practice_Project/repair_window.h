#ifndef REPAIR_WINDOW_H
#define REPAIR_WINDOW_H

#include <QMainWindow>
#include "findrepair.h"
#include "maintainrepair.h"
#include "distributerepair.h"

namespace Ui {
class Repair_Window;
}

class Repair_Window : public QMainWindow
{
    Q_OBJECT

public:
    explicit Repair_Window(QWidget *parent = nullptr);
    FindRepair *findrepairw;
    MaintainRepair *maintainrepairw;
    DistributeRepair *distributerepairw;
    ~Repair_Window();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::Repair_Window *ui;
};

#endif // REPAIR_WINDOW_H
