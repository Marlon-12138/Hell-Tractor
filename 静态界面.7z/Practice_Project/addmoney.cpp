#include "addmoney.h"
#include "ui_addmoney.h"

AddMoney::AddMoney(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AddMoney)
{
    ui->setupUi(this);
}

AddMoney::~AddMoney()
{
    delete ui;
}
