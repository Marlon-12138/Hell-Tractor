#include "findservice.h"
#include "ui_findservice.h"

FindService::FindService(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FindService)
{
    ui->setupUi(this);
}

FindService::~FindService()
{
    delete ui;
}
