#ifndef PRINTCONFIRMTABLE_H
#define PRINTCONFIRMTABLE_H

#include <QMainWindow>

namespace Ui {
class PrintConfirmTable;
}

class PrintConfirmTable : public QMainWindow
{
    Q_OBJECT

public:
    explicit PrintConfirmTable(QWidget *parent = nullptr);
    ~PrintConfirmTable();

private:
    Ui::PrintConfirmTable *ui;
};

#endif // PRINTCONFIRMTABLE_H
