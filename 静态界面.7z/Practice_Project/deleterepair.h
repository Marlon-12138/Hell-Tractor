#ifndef DELETEREPAIR_H
#define DELETEREPAIR_H

#include <QWidget>

namespace Ui {
class DeleteRepair;
}

class DeleteRepair : public QWidget
{
    Q_OBJECT

public:
    explicit DeleteRepair(QWidget *parent = nullptr);
    ~DeleteRepair();

private:
    Ui::DeleteRepair *ui;
};

#endif // DELETEREPAIR_H
