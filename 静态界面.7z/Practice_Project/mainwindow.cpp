#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "client_window.h"
#include "money_window.h"
#include "repair_window.h"
#include "service_window.h"
#include "warehouse_window.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_Run_Client_clicked()
{
    Client_Window *window = new Client_Window(this);
    window -> show();
}

void MainWindow::on_Run_Service_clicked()
{
    Service_Window *window = new Service_Window(this);
    window -> show();
}

void MainWindow::on_Run_Repair_clicked()
{
    Repair_Window *window = new Repair_Window(this);
    window -> show();
}

void MainWindow::on_Run_Money_clicked()
{
    Money_Window *window = new Money_Window(this);
    window -> show();
}

void MainWindow::on_Run_Warehouse_clicked()
{
    Warehouse_Window *window = new Warehouse_Window(this);
    window -> show();
}
