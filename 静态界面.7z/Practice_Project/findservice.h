#ifndef FINDSERVICE_H
#define FINDSERVICE_H

#include <QWidget>

namespace Ui {
class FindService;
}

class FindService : public QWidget
{
    Q_OBJECT

public:
    explicit FindService(QWidget *parent = nullptr);
    ~FindService();

private:
    Ui::FindService *ui;
};

#endif // FINDSERVICE_H
