#ifndef ADDSERVICE_H
#define ADDSERVICE_H

#include <QWidget>

namespace Ui {
class AddService;
}

class AddService : public QWidget
{
    Q_OBJECT

public:
    explicit AddService(QWidget *parent = nullptr);
    ~AddService();

private:
    Ui::AddService *ui;
};

#endif // ADDSERVICE_H
