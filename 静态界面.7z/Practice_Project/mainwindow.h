#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_Run_Client_clicked();

    void on_Run_Service_clicked();

    void on_Run_Repair_clicked();

    void on_Run_Money_clicked();

    void on_Run_Warehouse_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
